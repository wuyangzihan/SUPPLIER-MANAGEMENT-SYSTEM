# Supplier-Management-System-Project

 For Admin:
 Email: admin@admin.com
 password: admin
 
 For suppliers:
 you can Check database 
 
